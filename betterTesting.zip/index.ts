class Builder{
	constructor(public length: number, public width: number, public height: number){
		this.length = length,
		this.width = width,
		this.height = height
	}
	volume() {
		return this.length * this.width * this.height
	}
	area2d() {
		return this.length * this.height
	}
	surface3d() {
		let bigSides = (this.length * this.height) * 2
		let shortSides = (this.width * this.height) * 2
		let longSides = (this.width * this. length) * 2
		let surfaceArea = bigSides + shortSides + longSides
		return surfaceArea
	}
	perimeter2d(){
		return this.length + this.length + this.height + this.height
	}
}

export default Builder;



