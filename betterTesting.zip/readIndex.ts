import Builder from './index'
const inquirer = require('inquirer');

inquirer
	.prompt([
		{
			type: 'number',
			message: "What is the length of your object?",
			name: 'length'
		},
		{
			type: 'number',
			message: 'What is the width of your object?',
			name: 'width'
		},
		{
			type: 'number',
			message: 'What is the height of your object?',
			name: 'height'
		}
	]).then((answers) => {
		const newShape = new Builder(answers.length, answers.width, answers.height)
		inquirer
			.prompt([
				{
					type: "rawlist",
					message: "What measurement would you like to find?",
					choices: ["Volume", "2d Area", "3d Surface Area", "2d Perimeter"],
					name: "choice"
				}
			]).then((answer) => {
				if(answer.choice === "Volume"){
					console.log(newShape.volume())
				}else if(answer.choice === "2d Area"){
					console.log(newShape.area2d())
				}else if(answer.choice === "3d Surface Area"){
					console.log(newShape.surface3d())
				}else if(answer.choice === "2d Perimeter"){
					console.log(newShape.perimeter2d())
				}
			})
	}).catch((err) =>{
		console.log(err)
	})